from django.urls import path

from . import views
# This creates a namespace for my URLconf so Django can
#find the difference between my file and someone else's
#if someone has the same filename as mine on their blog.
app_name = 'polls'
# Creates a path for index, detail, results, and vote.
urlpatterns = [
    path('', views.IndexView.as_view(), name='index'),
    path('<int:pk>/', views.DetailView.as_view(), name='detail'),
    path('<int:pk>/results/', views.ResultsView.as_view(), name='results'),
    path('<int:question_id>/vote/', views.vote, name='vote'),
]
# The angle brackets capture part of the URL and 
#sends it as a keyword argument to the view function.
# The <int: part determines what patterns should match a part of a URL 
#(it's a converter).

